package WriteDataInExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class writeInExcel {
	
	public void WriteExcel(String sheetName, String cellValue,int row, int col) throws Exception {
		
		String excelPath = "C:\\Users\\hp\\eclipse-workspace\\Quiz3\\homeProjectWorkBook.xlsx";
		
		File file = new File(excelPath);
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheet(sheetName);
		
		sheet.getRow(row).createCell(col).setCellValue(cellValue);
		
		FileOutputStream fos = new FileOutputStream(new File(excelPath));
		wb.write(fos);
		fos.close();
		fis.close();
		
	}

}
