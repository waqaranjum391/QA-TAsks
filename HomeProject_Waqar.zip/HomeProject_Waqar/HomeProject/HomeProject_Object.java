package HomeProject;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HomeProject_Object {
	
	WebDriver driver=new ChromeDriver();	
	HomeProject_Methods Object = new HomeProject_Methods(driver);
	
	@BeforeTest (description="Step 0 : Starting Chrome")
	public void openChrome() throws InterruptedException{
		
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\4368\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		driver.get("https://www.galaxy.pk/");
		PropertyConfigurator.configure("log4j.properties");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}
	
	@AfterTest
	public void quitChrome() throws InterruptedException {
		
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Test
	public void HomeProject_Tasks() throws Exception {
		Object.Methods();
	}

}
