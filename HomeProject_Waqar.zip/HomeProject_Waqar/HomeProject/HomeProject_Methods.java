package HomeProject;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Waqar.Lab8_Methods;
import WriteDataInExcel.writeInExcel;

public class HomeProject_Methods {
	
	writeInExcel obj = new writeInExcel();
	Logger log=Logger.getLogger(Lab8_Methods.class);
	
	WebDriver driver;
		
	@FindBy(xpath="//a[@class='departments-menu-v2-title']")
	WebElement productsMenu;
	
	@FindBy(xpath="//ul[@id='menu-all-departments-1']//li[@id='menu-item-4761']")
	WebElement laptopsBtn;
	
	@FindBy(xpath="//h1[@class='product_title entry-title']")
	WebElement laptopName;
	
	@FindBy(xpath="(//span[@class='woocommerce-Price-amount amount'])[2]")
	WebElement laptopPrice;
	
	@FindBy(xpath="//div[@class='woocommerce-product-details__short-description']")
	WebElement laptopDescription;
	
	@FindBy(xpath="//select[@name='ppp']")
	WebElement numOfProductsDD;
	
	@FindBy(xpath="//img[@class='wp-post-image jetpack-lazy-image jetpack-lazy-image--handled']")
	WebElement laptopImage;
	
	public HomeProject_Methods(WebDriver drvr) {
		driver=drvr;
		PageFactory.initElements(drvr,this);
	}

	public void Methods() throws Exception{
				
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		
		log.info("Waiting for home page to load");
		wait.until(ExpectedConditions.visibilityOf(productsMenu));
		productsMenu.click();
		Thread.sleep(1000);
		
		log.info("Waiting for 'Laptops' button to be displayed");
		wait.until(ExpectedConditions.visibilityOf(laptopsBtn));
		laptopsBtn.click();
		Thread.sleep(2000);
		
		
		Select numOfProds = new Select(numOfProductsDD);
		numOfProds.selectByVisibleText("Show All");
		log.info("Select 'Show All' option from dropdown");
		Thread.sleep(2000);
		
		log.info("Iterating through all the items available on the webpage");
		for (int i=1; i<10; i++)
		{
			log.info("Click on the number"+i+"item");
			driver.findElement(By.xpath("(//div[@class='product-thumbnail product-item__thumbnail'])["+i+"]")).click();
			log.info("Get Description of this item");
			String Description=laptopDescription.getText();
			log.info("Get Name of this item");
			String Name= laptopName.getText();
			log.info("Get price of this item");
			String Price= laptopPrice.getText();
						
			log.info("Store Name of this item in excel file");
			obj.WriteExcel("tabletDetails", Name, i,1);
			log.info("Store Price of this item in excel file");
			obj.WriteExcel("tabletDetails", Price, i, 2);
			log.info("Store Description of this item in excel file");
			obj.WriteExcel("tabletDetails", Description, i, 3);
						
			Actions act=new Actions(driver);
			log.info("Right click on the image of this item");
			act.contextClick(laptopImage).build().perform();
			
			Robot robot = new Robot();
			
			log.info("Scroll to 'Save Image as' option using robot class");
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			
			log.info("Save the image at default location by pressing 'ENTER'");
			robot.keyPress(KeyEvent.VK_ENTER);	
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			
			log.info("Navigate back to the page containg all items.");
			driver.navigate().back();
			Thread.sleep(3000);
			
		}
	}

}
